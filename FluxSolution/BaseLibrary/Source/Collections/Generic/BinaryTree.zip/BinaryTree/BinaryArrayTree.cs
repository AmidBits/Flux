namespace Flux.Collections.Generic
{
  public class BinaryArrayTree<T>
    : BinaryTree<T>
  {
    private T[] m_data;

    public BinaryArrayTree(int size)
    {
      m_data = new T[size];

      for (var index = 0; index < m_data.Length; index++) m_data[index] = default!;
    }

    public void Delete(T value)
    {
      var index = System.Array.IndexOf(m_data, value);

      if (index > -1) m_data[index] = default!;
    }

    public int UniformIndex(int index) => index > 0 && index < m_data.Length ? index : -1;

    public int GetChildLeftIndex(int index) => !IsDefault(index) ? UniformIndex((index << 1) + 0) : -1;
    public int GetChildRightIndex(int index) => !IsDefault(index) ? UniformIndex((index << 1) + 1) : -1;

    public int GetHeight(int index) => !IsValidIndex(index) || IsDefault(index) || IsLeaf(index) ? 0 : 1 + Math.Max(GetHeight(GetChildLeftIndex(index)), GetHeight(GetChildRightIndex(index)));

    public static int GetParentIndex(int index) => (index - 1) >> 1;

    private void Insert(T value, int index)
    {
      if (index >= m_data.Length)
      {
        var newIndex = m_data.Length;

        System.Array.Resize(ref m_data, index + 1);

        for (; newIndex < m_data.Length; newIndex++) m_data[newIndex] = default!;
      }

      if (value == default) throw new System.ArgumentOutOfRangeException(nameof(value));
      else if (IsDefault(index)) m_data[index] = value;
      else
        switch (m_comparer.Compare(value, m_data[index]))
        {
          case -1:
            Insert(value, index << 1); // Try insert at left child.
            break;
          case 0:
          case 1:
            Insert(value, (index << 1) + 1); // Try insert at right child.
            break;
          default:
            throw new System.Exception();
        }
    }
    public void Insert(T value) => Insert(value, 1);

    public bool IsDefault(int index) => m_comparer.Compare(m_data[index], default!) == 0;

    public bool IsLeaf(int index) => (GetChildLeftIndex(index) is var indexL && indexL == -1 || IsDefault(indexL)) && (GetChildRightIndex(index) is var indexR && indexR == -1 || IsDefault(indexR));

    public bool IsValidIndex(int index) => index > 0 && index < m_data.Length;

    /// <summary>Rotate the node to left.</summary>
    /// <param name="node">The node to rotate left.</param>
    /// <returns>The pivot node that occupies the place of the provided node after the rotation.</returns>
    protected virtual int RotateLeft(int index)
    {
      //var p = index;
      //var a = GetChildLeftIndex(index);
      //var q = GetChildRightIndex(index);

      //var pivot = node.ChildRight;

      //node.ChildRight = pivot.ChildLeft;

      //if (pivot.ChildLeft != null) pivot.ChildLeft.Parent = node;

      //pivot.Parent = node.Parent;

      //if (node.Parent == null) m_root = pivot;
      //else if (node == node.Parent.ChildLeft) node.Parent.ChildLeft = pivot;
      //else node.Parent.ChildRight = pivot;

      //pivot.ChildLeft = node;

      //node.Parent = pivot;

      //return pivot;
      return index;
    }

    /// <summary>Rotate the tree right.</summary>
    /// <param name="node">Node on which to perform a right rotatation.</param>
    /// <returns>The pivot node that occupies the place of the provided node after the rotation.</returns>
    protected virtual int RotateRight(int index)
    {
      //var pivot = node.ChildLeft;

      //node.ChildLeft = pivot.ChildRight;

      //if (pivot.ChildRight != null) pivot.ChildRight.Parent = node;

      //pivot.Parent = node.Parent;

      //if (node.Parent == null) m_root = pivot;
      //else if (node == node.Parent.ChildRight) node.Parent.ChildRight = pivot;
      //else node.Parent.ChildLeft = pivot;

      //pivot.ChildRight = node;

      //node.Parent = pivot;

      //return pivot;
      return index;
    }
  }
}
