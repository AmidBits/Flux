using System.Linq;

namespace Flux.Collections.Generic
{
  /// <summary></summary>
  /// <see cref="https://en.wikipedia.org/wiki/Binary_search_tree"/>
  public class BinarySearchTree<T>
    : BinaryTree<T>
  {
    protected System.Collections.Generic.IComparer<T> m_comparer = System.Collections.Generic.Comparer<T>.Default;

    public Node? m_root;

    public int Size { get; protected set; }

    /// <summary>Balance the BST using the Day-Stout-Warren method.</summary>
    /// <see cref="https://en.wikipedia.org/wiki/Day–Stout–Warren_algorithm"/>
    public void BalanceDsw()
    {
      var pseudo = CreateNode(default!, null, null, m_root);

      TreeToVine(pseudo);
      VineToTree(pseudo, Size);

      m_root = pseudo.ChildRight;
      m_root.Parent = null;

      FixParents(m_root);

      static void FixParents(Node? node)
      {
        if (node != null)
        {
          if (node.ChildLeft != null)
          {
            node.ChildLeft.Parent = node;
            FixParents(node.ChildLeft);
          }
          if (node.ChildRight != null)
          {
            node.ChildRight.Parent = node;
            FixParents(node.ChildRight);
          }
        }
      }

      static void TreeToVine(Node root)
      {
        var tail = root;
        var rest = tail.ChildRight;

        while (rest != null)
        {
          if (rest.ChildLeft is null)
          {
            tail = rest;
            rest = rest.ChildRight;
          }
          else
          {
            var temp = rest.ChildLeft;
            rest.ChildLeft = temp.ChildRight;
            temp.ChildRight = rest;
            rest = temp;
            tail.ChildRight = temp;
          }
        }
      }

      static void VineToTree(Node root, int size)
      {
        var leaves = size + 1 - (int)System.Math.Pow(2, System.Math.Log(size + 1, 2));

        Compress(root, leaves);

        size -= leaves;

        while (size > 1)
        {
          size >>= 1;
          Compress(root, size);

          //size /= 2;
        }
      }

      static void Compress(Node? root, int size)
      {
        Node? scanner = root;

        if (scanner is null) throw new System.Exception();

        for (var i = 0; i < size; i++)
        {
          Node? child = scanner?.ChildRight;
          scanner!.ChildRight = child?.ChildRight;
          scanner = scanner.ChildRight;
          child!.ChildRight = scanner?.ChildLeft;
          scanner!.ChildLeft = child;
          //scanner.Parent = child.Parent;
          //child.Parent = scanner;
        }
      }
    }

    public virtual bool Contains(T value) => Search(value) != null;

    /// <summary>Override in order to be able to cast Node to a derived variant (if needed).</summary>
    public virtual Node CreateNode(T value, Node? parent, Node? left, Node? right) => new Node(value, parent, left, right);

    /// <summary>BST core delete node routine.</summary>
    /// <param name="delete">Node to delete.</param>
    private Node? DeleteNode(Node delete)
    {
      if (delete.ChildLeft is null && delete.ChildRight is null) return Replace(delete, null);
      else if (delete.ChildLeft is null) return Replace(delete, delete.ChildRight);
      else if (delete.ChildRight is null) return Replace(delete, delete.ChildLeft);
      else // Both children exists.
      {
        if (delete.ChildRight.GetSuccessor() is var successor && successor != null)
        {
        }

        if (delete.ChildLeft.GetAntecessor() is var antecessor && antecessor != null)
        {
        }

        return null;
      }
    }

    protected virtual Node? Delete(Node? remove)
    {
      Node? replacement = null;

      if (remove != null)
      {
        if (remove.ChildLeft is null && remove.ChildRight is null) replacement = Replace(remove, null);
        else if (remove.ChildLeft is null) replacement = Replace(remove, remove.ChildRight);
        else if (remove.ChildRight is null) replacement = Replace(remove, remove.ChildLeft);
        else
        {
          Node? successor = remove.ChildRight.GetMinimum();
          Delete(successor);
          Replace(remove, successor);
          //if (successor.Parent != remove)
          //{
          //  Replace(successor, successor.ChildRight);

          //  successor.ChildRight = remove.ChildRight;
          //  successor.ChildRight.Parent = successor;
          //}

          //Replace(remove, successor);

          //successor.ChildLeft = remove.ChildLeft;
          //successor.ChildLeft.Parent = successor;

          replacement = successor;
        }

        Size--;
      }

      return replacement;
    }
    public virtual Node? Delete(T value) => Delete(Search(value));

    public int GetCount() => (m_root ?? throw new System.ArgumentNullException(nameof(m_root))).GetCount();

    /// <summary>Get the maximum, i.e. the right-most, node.</summary>
    public T GetMaximum() => (m_root ?? throw new System.ArgumentNullException(nameof(m_root))).GetMaximum().Value;
    /// <summary>Get the min, i.e. the left-most, node.</summary>
    public T GetMinimum() => (m_root ?? throw new System.ArgumentNullException(nameof(m_root))).GetMinimum().Value;

    private Node? GetAntecessor() => (m_root ?? throw new System.ArgumentNullException(nameof(m_root))).GetAntecessor();

    protected Node? GetSuccessor(Node? node) // => node is null ? null : node.GetSuccessor();
    {
      if (node != null)
      {
        if (node.ChildRight != null) // If there is right branch, then successor is leftmost node of that subtree.
        {
          return node.ChildRight.GetMinimum();
        }
        else // Otherwise it is a lowest ancestor whose left child is also ancestor of node.
        {
          var parentNode = node.Parent;

          while (parentNode != null && node == parentNode.ChildRight) // Go up until we find parent that currentNode is not in right subtree.
          {
            node = parentNode;

            parentNode = parentNode.Parent;
          }

          return parentNode;
        }
      }

      return null;
    }

    /// <summary>BST core insert node routine.</summary>
    /// <param name="insert">Node to insert.</param>
    private void InsertNode(Node insert)
    {
      Node? walk = m_root;

      while (walk != null)
      {
        walk = m_comparer.Compare(insert.Value, walk.Value) < 0 ? walk.ChildLeft : walk.ChildRight;
      }
    }

    protected virtual Node Insert(Node node)
    {
      if (Size == 0)
      {
        m_root = node;
      }
      else
      {
        Node? parent = null;

        for (Node? search = m_root; search != null;)
        {
          parent = search;

          search = m_comparer.Compare(node.Value, search.Value) < 0 ? search.ChildLeft : search.ChildRight;
        }

        if (parent is null) throw new System.ArgumentNullException(nameof(parent));

        node.Parent = parent;

        switch (m_comparer.Compare(parent.Value, node.Value))
        {
          case var gt when gt > 0:
            parent.ChildLeft = node;
            break;
          case var lt when lt < 0:
            parent.ChildRight = node;
            break;
          default: throw new System.Exception();
        }
        node.Parent = parent;
      }

      Size++;

      return node;
    }
    public virtual Node Insert(T value) => Insert(CreateNode(value, null, null, null));

    /// <summary>Insert one node (replacement) in place of another (remove).</summary>
    /// <param name="remove">The node to remove from the tree.</param>
    /// <param name="replacement">The replacement node.</param>
    /// <returns>The replaced node.</returns>
    protected virtual Node? Replace(Node remove, Node? replacement)
    {
      if (remove.Parent is null) m_root = replacement;
      else if (remove == remove.Parent.ChildLeft) remove.Parent.ChildLeft = replacement;
      else if (remove == remove.Parent.ChildRight) remove.Parent.ChildRight = replacement;

      if (replacement != null)
      {
        replacement.Parent = remove.Parent;
        replacement.ChildLeft = remove.ChildLeft;
        replacement.ChildRight = remove.ChildRight;
      }

      return replacement;
    }

    /// <summary>Rotate the tree left by pivoting the root.</summary>
    public void RotateLeft() => m_root = (m_root ?? throw new System.ArgumentNullException(nameof(m_root))).RotateLeft();
    /// <summary>Rotate the tree right by pivoting the root.</summary>
    public void RotateRight() => m_root = (m_root ?? throw new System.ArgumentNullException(nameof(m_root))).RotateRight();

    /// <summary>Search for the node with the matching value, otherwise null.</summary>
    /// <param name="value">Value to search for.</param>
    /// <returns>The node with matching value if found, otherwise null.</returns>
    protected virtual Node? Search(T value)
    {
      var node = m_root;

      while (node != null && m_comparer.Compare(value, node.Value) is var compare && compare != 0)
      {
        node = compare < 0 ? node.ChildLeft : node.ChildRight;
      }

      return node;
    }

    public System.Collections.Generic.IEnumerable<Node> TraverseInOrder() => m_root?.TraverseInOrder() ?? throw new System.ArgumentNullException(nameof(m_root));
    public System.Collections.Generic.IEnumerable<Node> TraverseInOrderMorris() => m_root?.TraverseInOrderMorris() ?? throw new System.ArgumentNullException(nameof(m_root));
    public System.Collections.Generic.IEnumerable<Node> TraverseLevelOrder() => m_root?.TraverseLevelOrder() ?? throw new System.ArgumentNullException(nameof(m_root));
    public System.Collections.Generic.IEnumerable<Node[]> TraverseLevelOrderChunks() => m_root?.TraverseLevelOrderChunks() ?? throw new System.ArgumentNullException(nameof(m_root));
    public System.Collections.Generic.IEnumerable<Node> TraversePostOrder() => m_root?.TraversePostOrder() ?? throw new System.ArgumentNullException(nameof(m_root));
    public System.Collections.Generic.IEnumerable<Node> TraversePreOrder() => m_root?.TraversePreOrder() ?? throw new System.ArgumentNullException(nameof(m_root));

    public class Node
    {
      public Node? ChildLeft;
      public Node? ChildRight;

      public Node? Parent;

      public T Value;

      public Node(T value, Node? parent, Node? childLeft, Node? childRight)
      {
        ChildLeft = childLeft;
        ChildRight = childRight;
        Parent = parent;
        Value = value;
      }

      public Node? GetAntecessor()
      {
        var node = this.ChildLeft;

        while (!(node?.ChildRight is null))
        {
          node = node.ChildRight;
        }

        return node;
      }

      /// <summary>Yields the count of descendants plus this node.</summary>
      public int GetCount() => 1 + GetCountLeft() + GetCountRight();
      /// <summary>Yields the count of decendants in the left sub-tree.</summary>
      public int GetCountLeft() => ChildLeft?.GetCount() ?? 0;
      /// <summary>Yields the count of decendants in the right sub-tree.</summary>
      public int GetCountRight() => ChildRight?.GetCount() ?? 0;

      /// <summary>Returns the minimum item, or left most child, for the node. If there are no child nodes, the node itself is returned.</summary>
      public Node GetMinimum()
      {
        var node = this;

        while (!(node.ChildLeft is null))
        {
          node = node.ChildLeft;
        }

        return node;
      }
      /// <summary>Returns the maximum item, or right most child, for the node. If there are no child nodes, the node itself is returned.</summary>
      public Node GetMaximum()
      {
        var node = this;

        while (!(node.ChildRight is null))
        {
          node = node.ChildRight;
        }

        return node;
      }

      public Node? GetSuccessor()
      {
        var node = this.ChildRight;

        while (!(node?.ChildLeft is null))
        {
          node = node.ChildLeft;
        }

        return node;
      }

      /// <summary>Perform a left rotation and return the pivot node (the node replacing this node in a BST).</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_rotation"/>
      public Node? RotateLeft()
      {
        var pivot = ChildRight;

        if (!(pivot is null))
        {
          ChildRight = pivot.ChildLeft;
          if (!(pivot.ChildLeft is null)) pivot.ChildLeft.Parent = this;
          pivot.Parent = Parent;
          if (Parent is null) { }
          else if (this == Parent.ChildLeft) Parent.ChildLeft = pivot;
          else Parent.ChildRight = pivot;
          pivot.ChildLeft = this;
          Parent = pivot;
        }

        return pivot;
      }
      /// <summary>Perform a right rotation and return the pivot node (the node replacing this node in a BST).</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_rotation"/>
      public Node? RotateRight()
      {
        var pivot = ChildLeft;

        if (!(pivot is null))
        {
          ChildLeft = pivot.ChildRight;
          if (!(pivot.ChildRight is null)) pivot.ChildRight.Parent = this;
          pivot.Parent = Parent;
          if (Parent is null) { }
          else if (this == Parent.ChildRight) Parent.ChildRight = pivot;
          else Parent.ChildLeft = pivot;
          pivot.ChildRight = this;
          Parent = pivot;
        }

        return pivot;
      }

      /// <summary>In a binary search tree, in-order traversal retrieves data in sorted order.</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_traversal#In-order"/>
      public System.Collections.Generic.IEnumerable<Node> TraverseInOrder()
      {
        var stack = new System.Collections.Generic.Stack<Node>();

        Node? node = this;

        while (stack.Count > 0 || node != null)
        {
          if (node is null)
          {
            node = stack.Pop();

            yield return node;

            node = node.ChildRight;
          }
          else
          {
            stack.Push(node);

            node = node.ChildLeft;
          }
        }
      }
      /// <summary>Traversal the binary tree iteratively in-order left-to-right using the Morris Traversal(no Stack/Queue used).</summary>
      /// <see cref = "https://en.wikipedia.org/wiki/Threaded_binary_tree" />
      /// < seealso cref="https://en.wikipedia.org/wiki/Tree_traversal#Morris_in-order_traversal_using_threading"/>
      public System.Collections.Generic.IEnumerable<Node> TraverseInOrderMorris()
      {
        Node? node = this;

        while (node != null)
        {
          if (node.ChildLeft is null)
          {
            yield return node;

            node = node.ChildRight;
          }
          else
          {
            var predecessor = node.ChildLeft;

            while (predecessor.ChildRight != null && predecessor.ChildRight != node)
            {
              predecessor = predecessor.ChildRight;
            }

            if (predecessor.ChildRight is null) // Make current as the right child of its inorder predecessor.
            {
              predecessor.ChildRight = node;

              node = node.ChildLeft;
            }
            else // Revert the changes made in the if statement to restore the original tree, i.e. fix the right child of predecessor.
            {
              predecessor.ChildRight = null;

              yield return node;

              node = node.ChildRight;
            }
          }
        }
      }
      /// <summary>Level order, a.k.a. breadth first search (BFS), traversal yields the binary tree levels starting with the root, then its two children, then their children, and so on.</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_traversal#Breadth-first_search_/_level_order"/>
      public System.Collections.Generic.IEnumerable<Node> TraverseLevelOrder()
      {
        var queue = new System.Collections.Generic.Queue<Node>();

        queue.Enqueue(this);

        while (queue.Count > 0)
        {
          var node = queue.Dequeue();

          yield return node;

          if (node.ChildLeft != null) queue.Enqueue(node.ChildLeft);
          if (node.ChildRight != null) queue.Enqueue(node.ChildRight);
        }
      }
      /// <summary>Level order, a.k.a. breadth first search (BFS), traversal yields the binary tree levels in chunks starting with the root, then its two children, then their children, and so on.</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_traversal#Breadth-first_search_/_level_order"/>
      public System.Collections.Generic.IEnumerable<Node[]> TraverseLevelOrderChunks()
      {
        var level = new System.Collections.Generic.Queue<Node>();

        level.Enqueue(this);

        while (level.Count > 0)
        {
          yield return level.ToArray();

          var nextLevel = new System.Collections.Generic.Queue<Node>();

          foreach (var node in level)
          {
            if (node.ChildLeft != null) nextLevel.Enqueue(node.ChildLeft);
            if (node.ChildRight != null) nextLevel.Enqueue(node.ChildRight);
          }

          level = nextLevel;
        }
      }
      /// <summary>Post-order. (LRN)</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_traversal#Post-order"/>
      public System.Collections.Generic.IEnumerable<Node> TraversePostOrder()
      {
        var stack = new System.Collections.Generic.Stack<Node>();

        Node? node = this;

        var lastNodeVisited = default(Node);

        while (stack.Count > 0 || node != null)
        {
          if (node is null)
          {
            var peekNode = stack.Peek();

            if (peekNode.ChildRight != null && lastNodeVisited != peekNode.ChildRight)
            {
              node = peekNode.ChildRight;
            }
            else
            {
              yield return peekNode;

              lastNodeVisited = stack.Pop();
            }
          }
          else
          {
            stack.Push(node);

            node = node.ChildLeft;
          }
        }
      }
      /// <summary>The pre-order traversal is a topologically sorted one, because a parent node is processed before any of its child nodes is done. (NLR)</summary>
      /// <see cref="https://en.wikipedia.org/wiki/Tree_traversal#Pre-order"/>
      public System.Collections.Generic.IEnumerable<Node> TraversePreOrder()
      {
        var stack = new System.Collections.Generic.Stack<Node>();

        stack.Push(this);

        while (stack.Count > 0)
        {
          var node = stack.Pop();

          yield return node;

          if (node.ChildRight != null) stack.Push(node.ChildRight);
          if (node.ChildLeft != null) stack.Push(node.ChildLeft);
        }
      }

      public override string ToString() => $"{(Parent is null ? '\u2B71' : '\u2B61')}'{Value}'{(ChildLeft is null ? '\u2B70' : '\u21D9')}{(ChildRight is null ? '\u2B72' : '\u21D8')}";
    }
  }
}
