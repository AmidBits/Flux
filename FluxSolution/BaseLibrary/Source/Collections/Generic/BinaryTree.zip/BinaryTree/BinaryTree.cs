namespace Flux.Collections.Generic
{
  /// <summary></summary>
  /// <see cref="https://en.wikipedia.org/wiki/Binary_tree"/>
  public class BinaryTree<T>
  {
    protected System.Collections.Generic.IComparer<T> m_comparer = System.Collections.Generic.Comparer<T>.Default;
  }
}
