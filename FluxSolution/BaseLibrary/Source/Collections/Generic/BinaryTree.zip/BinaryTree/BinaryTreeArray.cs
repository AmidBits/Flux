namespace Flux
{
  public class BinaryTreeArray
  {
    private int[] m_data;

    public BinaryTreeArray(int size)
    {
      m_data = new int[size];
    }

    public void Delete(int value)
    {
      var index = System.Array.IndexOf(m_data, value);

      if (index > -1) m_data[index] = -1;
    }

    private void Insert(int value, int index)
    {
      if (index >= m_data.Length) System.Array.Resize(ref m_data, index + 1);

      if (m_data[index] == -1) m_data[index] = value;
      else if (value < m_data[index]) Insert(value, index << 2);
      else Insert(value, (index << 2) + 1);
    }
    public void Insert(int value) => Insert(value, 1);
  }
}
