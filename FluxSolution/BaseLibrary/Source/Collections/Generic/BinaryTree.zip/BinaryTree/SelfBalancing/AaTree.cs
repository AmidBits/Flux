namespace Flux.Collections.Generic
{
  /// <summary>
  /// 
  /// </summary>
  /// <seealso cref="https://github.com/ignl/BinarySearchTrees/blob/master/Trees/src/main/java/org/intelligentjava/algos/trees/AVLTree.java"/>
  public sealed class AaTree<T>
    : SelfBalancingBst<T>
  {
    public override Node CreateNode(T value, Node parent, Node left, Node right) => new AaNode(value, parent, left, right);

    private Node m_sentinel;
    private Node m_deleted;

    public AaTree()
    {
      m_root = m_sentinel = new AaNode(default, null, null, null);

      m_deleted = null;
    }

    private bool Delete(ref Node node, T value)
    {
      if (node == m_sentinel) return (m_deleted != null);

      if (m_comparer.Compare(value, node.Value) is var compare && compare < 0)
      {
        if (!Delete(ref node.ChildLeft, value)) return false;
      }
      else
      {
        if (compare == 0) m_deleted = node;

        if (!Delete(ref node.ChildRight, value)) return false;
      }

      if (m_deleted != null)
      {
        m_deleted.Value = node.Value;
        m_deleted = null;

        node = node.ChildRight;
      }
      else if (((AaNode)node.ChildLeft).Level < ((AaNode)node).Level - 1 || ((AaNode)node.ChildRight).Level < ((AaNode)node).Level - 1)
      {
        ((AaNode)node).Level--;

        if (((AaNode)node.ChildRight).Level > ((AaNode)node).Level) ((AaNode)node.ChildRight).Level = ((AaNode)node).Level;

        Skew(ref node);
        Skew(ref node.ChildRight);
        Skew(ref node.ChildRight.ChildRight);

        Split(ref node);
        Split(ref node.ChildRight);
      }

      return true;
    }
    protected override Node Delete(Node node) => Delete(ref m_root, node.Value) ? m_deleted : null;

    private bool Insert(ref Node node, T value)
    {
      if (node == m_sentinel)
      {
        node = new AaNode(value, null, m_sentinel, m_sentinel);

        return true;
      }

      if (m_comparer.Compare(value, node.Value) is var compare && compare < 0)
      {
        if (!Insert(ref node.ChildLeft, value)) return false;
      }
      else if (compare > 0)
      {
        if (!Insert(ref node.ChildRight, value)) return false;
      }
      else return false;

      Skew(ref node);

      Split(ref node);

      return true;
    }
    protected override Node Insert(Node node) => Insert(ref m_root, node.Value) ? m_sentinel : null;

    private AaNode Search(AaNode node, T value)
    {
      if (node == m_sentinel) return null;

      switch (m_comparer.Compare(value, node.Value))
      {
        case -1:
          return Search((AaNode)node.ChildLeft, value);
        case 1:
          return Search((AaNode)node.ChildRight, value);
        default:
          return node;
      }
    }
    protected override Node Search(T value) => Search((AaNode)m_root, value);

    private void Skew(ref Node node) // Rotates right.
    {
      if (((AaNode)node).Level == ((AaNode)node.ChildLeft).Level)
      {
        var left = node.ChildLeft;
        node.ChildLeft = left.ChildRight;
        left.ChildRight = node;
        node = (AaNode)left;
      }
    }

    private void Split(ref Node node) // Rotates left.
    {
      if (((AaNode)node.ChildRight.ChildRight).Level == ((AaNode)node).Level)
      {
        var right = node.ChildRight;
        node.ChildRight = right.ChildLeft;
        right.ChildLeft = node;
        node = (AaNode)right;
        ((AaNode)node).Level++;
      }
    }

    private class AaNode : Node
    {
      public int Level;

      public AaNode(T value, Node parent, Node left, Node right, int level)
        : base(value, parent, left, right)
      {
        Level = level;
      }
      public AaNode(T value, Node parent, Node left, Node right)
        : this(value, parent, left, right, default) { }
    }
  }
}
