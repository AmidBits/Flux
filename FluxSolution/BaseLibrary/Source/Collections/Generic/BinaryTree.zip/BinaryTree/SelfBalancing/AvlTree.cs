namespace Flux.Collections.Generic
{
  /// <summary>
  /// 
  /// </summary>
  /// <seealso cref="https://github.com/ignl/BinarySearchTrees/blob/master/Trees/src/main/java/org/intelligentjava/algos/trees/AVLTree.java"/>
  public sealed class AvlTree<T>
    : SelfBalancingBst<T>
  {
    public override Node CreateNode(T value, Node parent, Node left, Node right) => new AvlNode(value, parent, left, right);

    public override Node Delete(T value)
    {
      var delete = (AvlNode)base.Search(value);

      if (delete != null)
      {
        var successor = base.Delete(delete);

        if (successor != null)
        {
          // if replaced from GetMinimum(delete.ChildRight) then come back there and update heights
          AvlNode minimum = successor.ChildRight != null ? (AvlNode)successor.ChildRight.GetMinimum() : (AvlNode)successor;

          RecomputeHeight(minimum);
          Rebalance((AvlNode)minimum);
        }
        else
        {
          RecomputeHeight((AvlNode)delete.Parent);
          Rebalance((AvlNode)delete.Parent);
        }

        return successor;
      }

      return null;
    }

    public override Node Insert(T value)
    {
      var node = base.Insert(value);

      Rebalance((AvlNode)node);

      return node;
    }

    /// <summary>Returns higher height of 2 nodes.</summary>
    private int MaxHeight(AvlNode node1, AvlNode node2)
    {
      if (node1 != null && node2 != null)
      {
        return node1.Height > node2.Height ? node1.Height : node2.Height;
      }
      else if (node1 == null)
      {
        return node2 != null ? node2.Height : -1;
      }
      else if (node2 == null)
      {
        return node1 != null ? node1.Height : -1;
      }

      return -1;
    }

    /// <summary>Go up from inserted node, and update height and balance informations if needed. If some node balance reaches 2 or -2 that means that subtree must be rebalanced.</summary>
    private void Rebalance(AvlNode node)
    {
      while (node != null)
      {
        var parent = node.Parent;

        var leftHeight = (node.ChildLeft == null) ? -1 : ((AvlNode)node.ChildLeft).Height;
        var rightHeight = (node.ChildRight == null) ? -1 : ((AvlNode)node.ChildRight).Height;

        var nodeBalance = rightHeight - leftHeight;

        // rebalance (-2 means left subtree outgrow, 2 means right subtree)

        if (nodeBalance == 2)
        {
          if (node.ChildRight.ChildRight != null)
          {
            node = (AvlNode)RotateLeft(node);
            break;
          }
          else
          {
            node = (AvlNode)RotateRightThenLeft(node);
            break;
          }
        }
        else if (nodeBalance == -2)
        {
          if (node.ChildLeft.ChildLeft != null)
          {
            node = (AvlNode)RotateRight(node);
            break;
          }
          else
          {
            node = (AvlNode)RotateLeftThenRight(node);
            break;
          }
        }
        else
        {
          UpdateHeight(node);
        }

        node = (AvlNode)parent;
      }
    }

    /// <summary>Recomputes height information from the node and up for all of parents. It needs to be done after delete.</summary>
    private void RecomputeHeight(AvlNode node)
    {
      while (node != null)
      {
        node.Height = MaxHeight((AvlNode)node.ChildLeft, (AvlNode)node.ChildRight) + 1;

        node = (AvlNode)node.Parent;
      }
    }

    /// <summary>Rotates to left side.</summary>
    protected override Node RotateLeft(Node node)
    {
      var pivot = base.RotateLeft(node);

      UpdateHeight((AvlNode)pivot.ChildLeft);
      UpdateHeight((AvlNode)pivot);

      return pivot;
    }

    /// <summary>Take left child and rotate it to the left side first and then rotate node to the right side.</summary>
    private Node RotateLeftThenRight(Node node)
    {
      node.ChildLeft = RotateLeft(node.ChildLeft);

      return RotateRight(node);
    }

    /// <summary>Rotates to right side.</summary>
    protected override Node RotateRight(Node node)
    {
      var pivot = base.RotateRight(node);

      UpdateHeight((AvlNode)pivot.ChildRight);
      UpdateHeight((AvlNode)pivot);

      return pivot;
    }

    /// <summary>Take right child and rotate it to the right side first and then rotate node to the left side.</summary>
    private Node RotateRightThenLeft(Node node)
    {
      node.ChildRight = RotateRight(node.ChildRight);

      return RotateLeft(node);
    }

    /// <summary>Updates height and balance of the node.</summary>
    private void UpdateHeight(AvlNode node)
    {
      int leftHeight = (node.ChildLeft == null) ? -1 : ((AvlNode)node.ChildLeft).Height;
      int rightHeight = (node.ChildRight == null) ? -1 : ((AvlNode)node.ChildRight).Height;
      node.Height = 1 + System.Math.Max(leftHeight, rightHeight);
    }

    /// <summary>Node of AVL tree has height and balance additional properties. If balance equals 2 (or -2) that node needs to be re balanced. (Height is height of the subtree starting with this node, and balance is difference between left and right nodes heights).</summary>
    private class AvlNode : Node
    {
      public int Height;

      public AvlNode(T value, Node parent, Node left, Node right, int height)
        : base(value, parent, left, right)
      {
        Height = height;
      }
      public AvlNode(T value, Node parent, Node left, Node right)
        : base(value, parent, left, right) { }
    }
  }
}
