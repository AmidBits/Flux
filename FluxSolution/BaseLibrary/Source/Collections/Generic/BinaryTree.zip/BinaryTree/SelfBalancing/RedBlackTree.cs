namespace Flux.Collections.Generic
{
  /// <summary>
  /// 
  /// </summary>
  /// <seealso cref="https://github.com/ignl/BinarySearchTrees/blob/master/Trees/src/main/java/org/intelligentjava/algos/trees/RedBlackTree.java"/>
  public sealed class RedBlackTree<T>
    : SelfBalancingBst<T>
  {
    public enum ColorEnum
    {
      Red,
      Black
    }

    private static readonly RedBlackNode m_null = new RedBlackNode(default, null, null, null, ColorEnum.Red);

    public override Node CreateNode(T value, Node parent, Node left, Node right) => new RedBlackNode(value, parent, left, right, ColorEnum.Red);

    /// <summary>Slightly modified delete routine for red-black tree.</summary>
    protected override Node Delete(Node deleteNode)
    {
      Node replaceNode = null; // track node that replaces removedOrMovedNode

      if (deleteNode != null && deleteNode != m_null)
      {
        Node removedOrMovedNode = deleteNode; // same as deleteNode if it has only one child, and otherwise it replaces deleteNode

        ColorEnum removedOrMovedNodeColor = ((RedBlackNode)removedOrMovedNode).Color;


        if (deleteNode.ChildLeft == m_null)
        {
          replaceNode = deleteNode.ChildRight;

          RbtTransplant(deleteNode, deleteNode.ChildRight);
        }
        else if (deleteNode.ChildRight == m_null)
        {
          replaceNode = deleteNode.ChildLeft;

          RbtTransplant(deleteNode, deleteNode.ChildLeft);
        }
        else
        {
          removedOrMovedNode = deleteNode.ChildRight.GetMinimum();

          removedOrMovedNodeColor = ((RedBlackNode)removedOrMovedNode).Color;

          replaceNode = removedOrMovedNode.ChildRight;

          if (removedOrMovedNode.Parent == deleteNode)
          {
            replaceNode.Parent = removedOrMovedNode;
          }
          else
          {
            RbtTransplant(removedOrMovedNode, removedOrMovedNode.ChildRight);

            removedOrMovedNode.ChildRight = deleteNode.ChildRight;

            removedOrMovedNode.ChildRight.Parent = removedOrMovedNode;
          }

          RbtTransplant(deleteNode, removedOrMovedNode);

          removedOrMovedNode.ChildLeft = deleteNode.ChildLeft;

          removedOrMovedNode.ChildLeft.Parent = removedOrMovedNode;

          ((RedBlackNode)removedOrMovedNode).Color = ((RedBlackNode)deleteNode).Color;
        }

        Size--;

        if (removedOrMovedNodeColor == ColorEnum.Black)
        {
          DeleteRestore((RedBlackNode)replaceNode);
        }
      }

      return replaceNode;
    }

    // Restores Red-Black tree properties after delete if needed.
    private void DeleteRestore(RedBlackNode x)
    {
      while (x != m_root && IsBlack(x))
      {



        if (x == x.Parent.ChildLeft)
        {
          RedBlackNode w = (RedBlackNode)x.Parent.ChildRight;

          if (IsRed(w))
          { // case 1 - sibling is red

            w.Color = ColorEnum.Black;

            ((RedBlackNode)x.Parent).Color = ColorEnum.Red;

            RotateLeft(x.Parent);

            w = (RedBlackNode)x.Parent.ChildRight; // converted to case 2, 3 or 4
          }

          // case 2 sibling is black and both of its children are black

          if (IsBlack(w.ChildLeft) && IsBlack(w.ChildRight))
          {
            w.Color = ColorEnum.Red;

            x = (RedBlackNode)x.Parent;
          }
          else if (w != m_null)
          {
            if (IsBlack(w.ChildRight))
            { // case 3 sibling is black and its left child is red and right child is black
              ((RedBlackNode)w.ChildLeft).Color = ColorEnum.Black;

              w.Color = ColorEnum.Red;

              RotateRight(w);

              w = (RedBlackNode)x.Parent.ChildRight;
            }

            w.Color = ((RedBlackNode)x.Parent).Color; // case 4 sibling is black and right child is red

            ((RedBlackNode)x.Parent).Color = ColorEnum.Black;

            ((RedBlackNode)w.ChildRight).Color = ColorEnum.Black;

            RotateLeft(x.Parent);

            x = (RedBlackNode)m_root;
          }
          else
          {
            x.Color = ColorEnum.Black;

            x = (RedBlackNode)x.Parent;
          }

        }
        else
        {
          RedBlackNode w = (RedBlackNode)x.Parent.ChildLeft;

          if (IsRed(w))
          { // case 1 - sibling is red

            w.Color = ColorEnum.Black;

            ((RedBlackNode)x.Parent).Color = ColorEnum.Red;

            RotateRight(x.Parent);

            w = (RedBlackNode)x.Parent.ChildLeft; // converted to case 2, 3 or 4
          }

          // case 2 sibling is black and both of its children are black

          if (IsBlack(w.ChildLeft) && IsBlack(w.ChildRight))
          {

            w.Color = ColorEnum.Red;

            x = (RedBlackNode)x.Parent;
          }
          else if (w != m_null)
          {
            if (IsBlack(w.ChildLeft))
            { // case 3 sibling is black and its right child is red and left child is black

              ((RedBlackNode)w.ChildRight).Color = ColorEnum.Black;

              w.Color = ColorEnum.Red;

              RotateLeft(w);

              w = (RedBlackNode)x.Parent.ChildLeft;
            }

            w.Color = ((RedBlackNode)x.Parent).Color; // case 4 sibling is black and left child is red

            ((RedBlackNode)x.Parent).Color = ColorEnum.Black;

            ((RedBlackNode)w.ChildLeft).Color = ColorEnum.Black;

            RotateRight(x.Parent);

            x = (RedBlackNode)m_root;
          }
          else
          {
            x.Color = ColorEnum.Black;

            x = (RedBlackNode)x.Parent;
          }
        }
      }
    }

    //protected override Node GetMaxNode(Node node)
    //{
    //  if (node != null)
    //  {
    //    while (node.ChildRight != m_null)
    //    {
    //      node = node.ChildRight;
    //    }
    //  }

    //  return node;
    //}

    //protected override Node GetMinNode(Node node)
    //{
    //  if (node != null)
    //  {
    //    while (node.ChildLeft != m_null)
    //    {
    //      node = node.ChildLeft;
    //    }
    //  }

    //  return node;
    //}

    public override Node Insert(T value)
    {
      var newNode = base.Insert(value);

      newNode.ChildLeft = m_null;
      newNode.ChildRight = m_null;

      m_root.Parent = m_null;

      InsertRestore((RedBlackNode)newNode);

      return newNode;
    }

    // Restores Red-Black tree properties after insert if needed. Insert can break only 2 properties: root is red or if node is red then children must be black.
    private void InsertRestore(RedBlackNode currentNode)
    {
      // current node is always RED, so if its parent is red it breaks
      // Red-Black property, otherwise no fixup needed and loop can terminate

      while (currentNode.Parent != m_root && ((RedBlackNode)currentNode.Parent).Color == ColorEnum.Red)
      {
        RedBlackNode parent = (RedBlackNode)currentNode.Parent;

        RedBlackNode grandParent = (RedBlackNode)parent.Parent;

        if (parent == grandParent.ChildLeft)
        {
          RedBlackNode uncle = (RedBlackNode)grandParent.ChildRight;

          // case1 - uncle and parent are both red
          // re color both of them to black

          if (((RedBlackNode)uncle).Color == ColorEnum.Red)
          {
            parent.Color = ColorEnum.Black;
            uncle.Color = ColorEnum.Black;
            grandParent.Color = ColorEnum.Red;

            // grandparent was recolored to red, so in next iteration we check if it does not break Red-Black property

            currentNode = grandParent;
          }
          else // case 2/3 uncle is black - then we perform rotations
          {
            if (currentNode == parent.ChildRight)
            { // case 2, first rotate left
              currentNode = parent;

              RotateLeft(currentNode);

              parent = (RedBlackNode)currentNode.Parent;
            }

            // do not use parent

            parent.Color = ColorEnum.Black; // case 3

            grandParent.Color = ColorEnum.Red;

            RotateRight(grandParent);
          }
        }
        else if (parent == grandParent.ChildRight)
        {
          RedBlackNode uncle = (RedBlackNode)grandParent.ChildLeft;

          // case1 - uncle and parent are both red
          // re color both of them to black
          if (((RedBlackNode)uncle).Color == ColorEnum.Red)
          {
            parent.Color = ColorEnum.Black;
            uncle.Color = ColorEnum.Black;
            grandParent.Color = ColorEnum.Red;

            // grandparent was recolored to red, so in next iteration we check if it does not break Red-Black property
            currentNode = grandParent;
          }
          else // case 2/3 uncle is black - then we perform rotations
          {
            if (currentNode == parent.ChildLeft)
            { // case 2, first rotate right
              currentNode = parent;

              RotateRight(currentNode);

              parent = (RedBlackNode)currentNode.Parent;
            }

            // do not use parent

            parent.Color = ColorEnum.Black; // case 3

            grandParent.Color = ColorEnum.Red;

            RotateLeft(grandParent);
          }
        }
      }

        // ensure root is black in case it was colored red in fixup
        ((RedBlackNode)m_root).Color = ColorEnum.Black;
    }

    private bool IsBlack(Node node)
    {
      return node != null ? ((RedBlackNode)node).Color == ColorEnum.Black : false;
    }
    private bool IsRed(Node node)
    {
      return node != null ? ((RedBlackNode)node).Color == ColorEnum.Red : false;
    }

    protected override Node RotateLeft(Node node)
    {
      Node temp = node.ChildRight;

      temp.Parent = node.Parent;

      node.ChildRight = temp.ChildLeft;

      if (node.ChildRight != m_null)
      {
        node.ChildRight.Parent = node;
      }

      temp.ChildLeft = node;

      node.Parent = temp;

      // temp took over node's place so now its parent should point to temp

      if (temp.Parent != m_null)
      {
        if (node == temp.Parent.ChildLeft)
        {
          temp.Parent.ChildLeft = temp;
        }
        else
        {
          temp.Parent.ChildRight = temp;
        }
      }
      else
      {
        m_root = temp;
      }

      return temp;
    }
    protected override Node RotateRight(Node node)
    {
      Node temp = node.ChildLeft;

      temp.Parent = node.Parent;

      node.ChildLeft = temp.ChildRight;

      if (node.ChildLeft != m_null)
      {
        node.ChildLeft.Parent = node;
      }

      temp.ChildRight = node;

      node.Parent = temp;

      // temp took over node's place so now its parent should point to temp

      if (temp.Parent != m_null)
      {
        if (node == temp.Parent.ChildLeft)
        {
          temp.Parent.ChildLeft = temp;
        }
        else
        {
          temp.Parent.ChildRight = temp;
        }
      }
      else
      {
        m_root = temp;
      }

      return temp;
    }

    // Similar to original transplant() method in BST but uses nilNode instead of null.
    private Node RbtTransplant(Node nodeToReplace, Node newNode)
    {
      if (nodeToReplace.Parent == m_null)
      {
        m_root = newNode;
      }
      else if (nodeToReplace == nodeToReplace.Parent.ChildLeft)
      {
        nodeToReplace.Parent.ChildLeft = newNode;
      }
      else
      {
        nodeToReplace.Parent.ChildRight = newNode;
      }

      newNode.Parent = nodeToReplace.Parent;

      return newNode;
    }

    /// <summary>Node of AVL tree has height and balance additional properties. If balance equals 2 (or -2) that node needs to be re balanced. (Height is height of the subtree starting with this node, and balance is difference between left and right nodes heights).</summary>
    private class RedBlackNode : Node
    {
      public ColorEnum Color;

      public RedBlackNode(T value, Node parent, Node left, Node right, ColorEnum color)
        : base(value, parent, left, right)
      {
        Color = color;
      }
    }
  }
}
