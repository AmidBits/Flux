namespace Flux.Collections.Generic
{
  /// <summary></summary>
  /// <see cref="https://en.wikipedia.org/wiki/Self-balancing_binary_search_tree"/>
  public abstract class SelfBalancingBst<T>
    : BinarySearchTree<T>
  {
    /// <summary>Rotate the node to left.</summary>
    /// <param name="node">The node to rotate left.</param>
    /// <returns>The pivot node that occupies the place of the provided node after the rotation.</returns>
    protected virtual Node RotateLeft(Node node)
    {
      var pivot = node.ChildRight;

      node.ChildRight = pivot.ChildLeft;

      if (pivot.ChildLeft != null) pivot.ChildLeft.Parent = node;

      pivot.Parent = node.Parent;

      if (node.Parent == null) m_root = pivot;
      else if (node == node.Parent.ChildLeft) node.Parent.ChildLeft = pivot;
      else node.Parent.ChildRight = pivot;

      pivot.ChildLeft = node;

      node.Parent = pivot;

      return pivot;
    }
    /// <summary>Rotate the tree right.</summary>
    /// <param name="node">Node on which to perform a right rotatation.</param>
    /// <returns>The pivot node that occupies the place of the provided node after the rotation.</returns>
    protected virtual Node RotateRight(Node node)
    {
      var pivot = node.ChildLeft;

      node.ChildLeft = pivot.ChildRight;

      if (pivot.ChildRight != null) pivot.ChildRight.Parent = node;

      pivot.Parent = node.Parent;

      if (node.Parent == null) m_root = pivot;
      else if (node == node.Parent.ChildRight) node.Parent.ChildRight = pivot;
      else node.Parent.ChildLeft = pivot;

      pivot.ChildRight = node;

      node.Parent = pivot;

      return pivot;
    }
  }
}
