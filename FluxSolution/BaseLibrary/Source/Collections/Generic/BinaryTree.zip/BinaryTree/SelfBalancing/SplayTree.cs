namespace Flux.Collections.Generic
{
  /// <summary>
  /// 
  /// </summary>
  /// <seealso cref="https://github.com/ignl/BinarySearchTrees/blob/master/Trees/src/main/java/org/intelligentjava/algos/trees/SplayTree.java"/>
  public class SplayTree<T>
    : SelfBalancingBst<T>
  {
    public SplayTree() => m_root = null;

    public override Node Delete(T value)
    {
      Node successor = null;

      if (base.Search(value) is var delete && delete != null)
      {
        var parent = delete.Parent;

        successor = base.Delete(delete);

        if (parent != null) Splay(parent);
      }

      return successor;
    }

    public override Node Insert(T value)
    {
      var insert = base.Insert(value);

      Splay(insert);

      return insert;
    }

    protected override Node Search(T value)
    {
      var search = base.Search(value);

      if (search != null) Splay(search);

      return search;
    }

    protected void Splay(Node node)
    {
      // move node up until its root
      while (node != m_root)
      {
        // Zig step
        var parent = node.Parent;

        if (parent == m_root)
        {
          if (node == parent.ChildLeft)
          {
            RotateRight(parent);
          }
          else if (node == parent.ChildRight)
          {
            RotateLeft(parent);
          }

          break;
        }
        else
        {
          var grandParent = parent.Parent;

          var nodeAndParentLeftChildren = node.Equals(parent.ChildLeft) && parent.Equals(grandParent.ChildLeft);
          var nodeAndParentRightChildren = node.Equals(parent.ChildRight) && parent.Equals(grandParent.ChildRight);
          var nodeRightChildParentLeftChild = node.Equals(parent.ChildRight) && parent.Equals(grandParent.ChildLeft);
          var nodeLeftChildParentRightChild = node.Equals(parent.ChildLeft) && parent.Equals(grandParent.ChildRight);


          if (nodeAndParentLeftChildren) // Zig zig step to the right.
          {
            RotateRight(grandParent);
            RotateRight(parent);
          }

          else if (nodeAndParentRightChildren) // Zig zig step to the left.
          {
            RotateLeft(grandParent);
            RotateLeft(parent);
          }

          else if (nodeRightChildParentLeftChild) // Zig zag steps, left and right.
          {
            RotateLeft(parent);
            RotateRight(grandParent);
          }
          else if (nodeLeftChildParentRightChild) // Zig zag steps, right and left.
          {
            RotateRight(parent);
            RotateLeft(grandParent);
          }
        }
      }
    }
  }
}
