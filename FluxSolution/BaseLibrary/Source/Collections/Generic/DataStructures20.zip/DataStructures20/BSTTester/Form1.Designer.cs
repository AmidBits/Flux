﻿namespace BSTTester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.val = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnContains = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radPostorder = new System.Windows.Forms.RadioButton();
            this.radInorder = new System.Windows.Forms.RadioButton();
            this.radPreorder = new System.Windows.Forms.RadioButton();
            this.output = new System.Windows.Forms.TextBox();
            this.btnRandomTests = new System.Windows.Forms.Button();
            this.saveTestRunsDlg = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
// 
// label1
// 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter a string value: ";
// 
// val
// 
            this.val.Location = new System.Drawing.Point(165, 13);
            this.val.Name = "val";
            this.val.TabIndex = 1;
// 
// btnAdd
// 
            this.btnAdd.Location = new System.Drawing.Point(13, 46);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
// 
// btnRemove
// 
            this.btnRemove.Location = new System.Drawing.Point(95, 46);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
// 
// btnContains
// 
            this.btnContains.Location = new System.Drawing.Point(177, 46);
            this.btnContains.Name = "btnContains";
            this.btnContains.TabIndex = 4;
            this.btnContains.Text = "Contains";
            this.btnContains.Click += new System.EventHandler(this.btnContains_Click);
// 
// btnClear
// 
            this.btnClear.Location = new System.Drawing.Point(259, 46);
            this.btnClear.Name = "btnClear";
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
// 
// groupBox1
// 
            this.groupBox1.Controls.Add(this.radPostorder);
            this.groupBox1.Controls.Add(this.radInorder);
            this.groupBox1.Controls.Add(this.radPreorder);
            this.groupBox1.Location = new System.Drawing.Point(13, 86);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(321, 51);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Traversal Method";
// 
// radPostorder
// 
            this.radPostorder.AutoSize = true;
            this.radPostorder.Location = new System.Drawing.Point(183, 20);
            this.radPostorder.Name = "radPostorder";
            this.radPostorder.Size = new System.Drawing.Size(66, 17);
            this.radPostorder.TabIndex = 2;
            this.radPostorder.Text = "Postorder";
            this.radPostorder.CheckedChanged += new System.EventHandler(this.radPostorder_CheckedChanged);
// 
// radInorder
// 
            this.radInorder.AutoSize = true;
            this.radInorder.Checked = true;
            this.radInorder.Location = new System.Drawing.Point(95, 20);
            this.radInorder.Name = "radInorder";
            this.radInorder.Size = new System.Drawing.Size(54, 17);
            this.radInorder.TabIndex = 1;
            this.radInorder.TabStop = true;
            this.radInorder.Text = "Inorder";
            this.radInorder.CheckedChanged += new System.EventHandler(this.radInorder_CheckedChanged);
// 
// radPreorder
// 
            this.radPreorder.AutoSize = true;
            this.radPreorder.Location = new System.Drawing.Point(7, 20);
            this.radPreorder.Name = "radPreorder";
            this.radPreorder.Size = new System.Drawing.Size(61, 17);
            this.radPreorder.TabIndex = 0;
            this.radPreorder.Text = "Preorder";
            this.radPreorder.CheckedChanged += new System.EventHandler(this.radPreorder_CheckedChanged);
// 
// output
// 
            this.output.AutoSize = false;
            this.output.Location = new System.Drawing.Point(13, 154);
            this.output.Multiline = true;
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(321, 238);
            this.output.TabIndex = 7;
// 
// btnRandomTests
// 
            this.btnRandomTests.Location = new System.Drawing.Point(85, 399);
            this.btnRandomTests.Name = "btnRandomTests";
            this.btnRandomTests.Size = new System.Drawing.Size(180, 23);
            this.btnRandomTests.TabIndex = 8;
            this.btnRandomTests.Text = "Run Random Test";
            this.btnRandomTests.Click += new System.EventHandler(this.btnRandomTests_Click);
// 
// saveTestRunsDlg
// 
            this.saveTestRunsDlg.DefaultExt = "log";
            this.saveTestRunsDlg.Filter = "Log Files|*.log|All Files|*.*";
// 
// Form1
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(353, 429);
            this.Controls.Add(this.btnRandomTests);
            this.Controls.Add(this.output);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnContains);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.val);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "BST Tester";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox val;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnContains;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radPreorder;
        private System.Windows.Forms.RadioButton radInorder;
        private System.Windows.Forms.RadioButton radPostorder;
        private System.Windows.Forms.TextBox output;
        private System.Windows.Forms.Button btnRandomTests;
        private System.Windows.Forms.SaveFileDialog saveTestRunsDlg;
    }
}

