﻿#region Using directives

using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SkmDataStructures2;


#endregion

namespace BSTTester
{
    partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private BinarySearchTree<string> bst = new BinarySearchTree<string>();

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bst.Add(val.Text);
            ShowTree();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (!bst.Remove(val.Text))
                MessageBox.Show("The value " + val.Text + " does not exist in the BST.");
            ShowTree();
        }

        private void btnContains_Click(object sender, EventArgs e)
        {
            if (bst.Contains(val.Text))
                MessageBox.Show(val.Text + " exists in the BST.");
            else
                MessageBox.Show(val.Text + " does NOT exist in the BST.");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            bst.Clear();
            ShowTree();
        }


        private void ShowTree()
        {
            output.Text = string.Empty;
            StringBuilder results = new StringBuilder(5 * bst.Count);

            TraversalMethod traversalMethod = TraversalMethod.Preorder;
            if (radInorder.Checked) traversalMethod = TraversalMethod.Inorder;
            if (radPostorder.Checked) traversalMethod = TraversalMethod.Postorder;

            IEnumerator<string> iter = bst.GetEnumerator(traversalMethod);

            while (iter.MoveNext())
                results.Append(iter.Current.ToString()).Append(", ");

            output.Text = results.ToString();
        }

        private void radPreorder_CheckedChanged(object sender, EventArgs e)
        {
            ShowTree();
        }

        private void radInorder_CheckedChanged(object sender, EventArgs e)
        {
            ShowTree();
        }

        private void radPostorder_CheckedChanged(object sender, EventArgs e)
        {
            ShowTree();
        }

        private void btnRandomTests_Click(object sender, EventArgs e)
        {
            if (this.saveTestRunsDlg.ShowDialog() == DialogResult.Cancel)
                return;

            // open the file for writing			
            StreamWriter sw = new StreamWriter(this.saveTestRunsDlg.OpenFile());
            sw.WriteLine(String.Concat("BEGINNING TEST RUN AT ", DateTime.Now.ToString()));

            Cursor oldCursor = this.Cursor;
            this.Cursor = Cursors.WaitCursor;

            // run tests
            Random rndNumbers = new Random();

            const int TEST_RUNS = 100;
            const int MIN_NODES = 500;
            const int MIN_REMOVALS = 200;

            List<int> addedNodes;
            bool passed = true;

            for (int run = 0; run < TEST_RUNS; run++)
            {
                sw.WriteLine(String.Concat("Entering test run ", run));

                BinarySearchTree<int> bst = new BinarySearchTree<int>();

                int nodes = rndNumbers.Next(MIN_NODES) + MIN_NODES;

                sw.WriteLine(String.Concat("Nodes to add: ", nodes));

                addedNodes = null;
                addedNodes = new List<int>(nodes);

                // do inserts
                for (int node = 0; node < nodes; node++)
                {
                    int newValue = rndNumbers.Next(Int32.MaxValue);
                    bst.Add(newValue);

                    addedNodes.Add(newValue);

                    sw.WriteLine(String.Concat("\tAdded Node: ", newValue));
                }

                // do deletes
                int removals = rndNumbers.Next(MIN_REMOVALS) + MIN_REMOVALS;
                sw.WriteLine(String.Concat("Nodes to delete: ", removals));
                for (int remove = 0; remove < removals; remove++)
                {
                    int index = rndNumbers.Next(addedNodes.Count);
                    bst.Remove(addedNodes[index]);

                    sw.WriteLine(String.Concat("\tDeleted node: ", addedNodes[index]));

                    addedNodes.RemoveAt(index);
                }

                // make sure everything matches up
                string message = string.Empty;
                int expectedCount = nodes - removals;
                if (bst.Count != expectedCount)
                    message += String.Format("Count doesn't match up! For BST, {0}, expected {1}\r\n", bst.Count, expectedCount);

                // loop through nodes and tree, to make sure there is a 1-1 correspondence
                for (int i = 0; i < addedNodes.Count; i++)
                {
                    int addedValue = addedNodes[i];

                    sw.Write(String.Concat("Ensuring BST contains node ", addedValue));

                    if (!bst.Contains(addedValue))
                    {
                        message += String.Concat("BST does not contain ", addedValue.ToString(), "\r\n");
                        sw.WriteLine("  -- FAILED!!");
                    }
                    else
                        sw.WriteLine("  -- CHECK");
                }

                // make sure inorder traversal is working
                // sort the addedNodes list:
                addedNodes.Sort();

                // now, make sure it maps up to the inorder traversal
                int k = 0;
                bool validOrdering = true;
                foreach (int val in bst.Inorder)
                {
                    if (val != addedNodes[k++])
                    {
                        validOrdering = false;
                        break;
                    }
                }

                if (!validOrdering)
                {
                    message += "Inorder traversal doesn't match sorted results!";
                    sw.WriteLine("Inorder traversal doesn't match sorted results!");
                }
                else
                    sw.WriteLine("*** Inorder traversal matched sorted results!");

                if (message.Length > 0)
                {
                    sw.WriteLine(String.Format("Anamoly on run {0}: {1}", run.ToString(), message));
                    MessageBox.Show(String.Format("Anamoly on run {0}: {1}", run.ToString(), message));
                    passed = false;
                }
                else
                    sw.WriteLine(String.Concat("Run ", run, " has passed...\r\n"));
            }

            if (passed)
                MessageBox.Show("BST data structure passed " + TEST_RUNS + " test cases...");

            sw.WriteLine(String.Concat("COMPLETED TEST RUN AT ", DateTime.Now.ToString()));
            sw.Close();		// close the file

            this.Cursor = oldCursor;
        }
    }
} 