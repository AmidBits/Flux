﻿namespace SetTester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lowerBound = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.upperBound = new System.Windows.Forms.NumericUpDown();
            this.btnCreateSet = new System.Windows.Forms.Button();
            this.grpSetOperations = new System.Windows.Forms.GroupBox();
            this.btnProperSubset = new System.Windows.Forms.Button();
            this.btnIsSubset = new System.Windows.Forms.Button();
            this.btnComplement = new System.Windows.Forms.Button();
            this.btnDifference = new System.Windows.Forms.Button();
            this.btnIntersect = new System.Windows.Forms.Button();
            this.setContents = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUnion = new System.Windows.Forms.Button();
            this.ints = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCountCharacters = new System.Windows.Forms.Button();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.lowerBound)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upperBound)).BeginInit();
            this.grpSetOperations.SuspendLayout();
            this.SuspendLayout();
// 
// label1
// 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Specify the Set\'s Bounds: ";
// 
// lowerBound
// 
            this.lowerBound.Location = new System.Drawing.Point(177, 4);
            this.lowerBound.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.lowerBound.Name = "lowerBound";
            this.lowerBound.Size = new System.Drawing.Size(51, 20);
            this.lowerBound.TabIndex = 1;
// 
// label2
// 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(235, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "to";
// 
// upperBound
// 
            this.upperBound.Location = new System.Drawing.Point(260, 4);
            this.upperBound.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.upperBound.Name = "upperBound";
            this.upperBound.Size = new System.Drawing.Size(51, 20);
            this.upperBound.TabIndex = 3;
            this.upperBound.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
// 
// btnCreateSet
// 
            this.btnCreateSet.Location = new System.Drawing.Point(332, 4);
            this.btnCreateSet.Name = "btnCreateSet";
            this.btnCreateSet.Size = new System.Drawing.Size(118, 23);
            this.btnCreateSet.TabIndex = 4;
            this.btnCreateSet.Text = "Create Set";
            this.btnCreateSet.Click += new System.EventHandler(this.btnCreateSet_Click);
// 
// grpSetOperations
// 
            this.grpSetOperations.Controls.Add(this.btnProperSubset);
            this.grpSetOperations.Controls.Add(this.btnIsSubset);
            this.grpSetOperations.Controls.Add(this.btnComplement);
            this.grpSetOperations.Controls.Add(this.btnDifference);
            this.grpSetOperations.Controls.Add(this.btnIntersect);
            this.grpSetOperations.Controls.Add(this.setContents);
            this.grpSetOperations.Controls.Add(this.label4);
            this.grpSetOperations.Controls.Add(this.btnUnion);
            this.grpSetOperations.Controls.Add(this.ints);
            this.grpSetOperations.Controls.Add(this.label3);
            this.grpSetOperations.Enabled = false;
            this.grpSetOperations.Location = new System.Drawing.Point(3, 42);
            this.grpSetOperations.Name = "grpSetOperations";
            this.grpSetOperations.Size = new System.Drawing.Size(447, 327);
            this.grpSetOperations.TabIndex = 5;
            this.grpSetOperations.TabStop = false;
            this.grpSetOperations.Text = "Set Operations";
// 
// btnProperSubset
// 
            this.btnProperSubset.Location = new System.Drawing.Point(232, 158);
            this.btnProperSubset.Name = "btnProperSubset";
            this.btnProperSubset.Size = new System.Drawing.Size(100, 23);
            this.btnProperSubset.TabIndex = 14;
            this.btnProperSubset.Text = "Is Proper Subset?";
            this.btnProperSubset.Click += new System.EventHandler(this.btnProperSubset_Click);
// 
// btnIsSubset
// 
            this.btnIsSubset.Location = new System.Drawing.Point(112, 158);
            this.btnIsSubset.Name = "btnIsSubset";
            this.btnIsSubset.TabIndex = 13;
            this.btnIsSubset.Text = "Is Subset?";
            this.btnIsSubset.Click += new System.EventHandler(this.btnIsSubset_Click);
// 
// btnComplement
// 
            this.btnComplement.Location = new System.Drawing.Point(308, 94);
            this.btnComplement.Name = "btnComplement";
            this.btnComplement.Size = new System.Drawing.Size(77, 47);
            this.btnComplement.TabIndex = 12;
            this.btnComplement.Text = "Complement the Set";
            this.btnComplement.Click += new System.EventHandler(this.btnComplement_Click);
// 
// btnDifference
// 
            this.btnDifference.Location = new System.Drawing.Point(217, 94);
            this.btnDifference.Name = "btnDifference";
            this.btnDifference.Size = new System.Drawing.Size(73, 47);
            this.btnDifference.TabIndex = 11;
            this.btnDifference.Text = "Set Difference";
            this.btnDifference.Click += new System.EventHandler(this.btnDifference_Click);
// 
// btnIntersect
// 
            this.btnIntersect.Location = new System.Drawing.Point(130, 94);
            this.btnIntersect.Name = "btnIntersect";
            this.btnIntersect.Size = new System.Drawing.Size(75, 47);
            this.btnIntersect.TabIndex = 10;
            this.btnIntersect.Text = "Intersect Integers";
            this.btnIntersect.Click += new System.EventHandler(this.btnIntersect_Click);
// 
// setContents
// 
            this.setContents.AutoSize = false;
            this.setContents.Location = new System.Drawing.Point(10, 215);
            this.setContents.Multiline = true;
            this.setContents.Name = "setContents";
            this.setContents.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.setContents.Size = new System.Drawing.Size(415, 106);
            this.setContents.TabIndex = 9;
// 
// label4
// 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Set Contents:";
// 
// btnUnion
// 
            this.btnUnion.Location = new System.Drawing.Point(57, 94);
            this.btnUnion.Name = "btnUnion";
            this.btnUnion.Size = new System.Drawing.Size(59, 47);
            this.btnUnion.TabIndex = 8;
            this.btnUnion.Text = "Union Integers";
            this.btnUnion.Click += new System.EventHandler(this.btnUnion_Click);
// 
// ints
// 
            this.ints.AutoSize = false;
            this.ints.Location = new System.Drawing.Point(133, 14);
            this.ints.Multiline = true;
            this.ints.Name = "ints";
            this.ints.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.ints.Size = new System.Drawing.Size(292, 63);
            this.ints.TabIndex = 7;
// 
// label3
// 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 76);
            this.label3.TabIndex = 6;
            this.label3.Text = "Comma-Delimited List of Integers:";
// 
// btnCountCharacters
// 
            this.btnCountCharacters.Location = new System.Drawing.Point(149, 383);
            this.btnCountCharacters.Name = "btnCountCharacters";
            this.btnCountCharacters.Size = new System.Drawing.Size(162, 23);
            this.btnCountCharacters.TabIndex = 6;
            this.btnCountCharacters.Text = "Character Count Test";
            this.btnCountCharacters.Click += new System.EventHandler(this.btnCountCharacters_Click);
// 
// Form1
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(462, 418);
            this.Controls.Add(this.btnCountCharacters);
            this.Controls.Add(this.grpSetOperations);
            this.Controls.Add(this.btnCreateSet);
            this.Controls.Add(this.upperBound);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lowerBound);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Set Tester";
            ((System.ComponentModel.ISupportInitialize)(this.lowerBound)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upperBound)).EndInit();
            this.grpSetOperations.ResumeLayout(false);
            this.grpSetOperations.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown lowerBound;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown upperBound;
        private System.Windows.Forms.Button btnCreateSet;
        private System.Windows.Forms.GroupBox grpSetOperations;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ints;
        private System.Windows.Forms.Button btnUnion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox setContents;
        private System.Windows.Forms.Button btnIntersect;
        private System.Windows.Forms.Button btnDifference;
        private System.Windows.Forms.Button btnComplement;
        private System.Windows.Forms.Button btnIsSubset;
        private System.Windows.Forms.Button btnProperSubset;
        private System.Windows.Forms.Button btnCountCharacters;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
    }
}

