﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SkmDataStructures2;
using System.IO;

#endregion

namespace SetTester
{
    partial class Form1 : Form
    {
        private PascalSet pSet = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreateSet_Click(object sender, EventArgs e)
        {
            try
            {
                pSet = new PascalSet(Convert.ToInt32(lowerBound.Value), Convert.ToInt32(upperBound.Value));
                MessageBox.Show(string.Format("Set created with lowerbound {0} and upperbound {1}.", lowerBound.Value, upperBound.Value));
                this.grpSetOperations.Enabled = true;
            }
            catch (ArgumentException ae)
            {
                MessageBox.Show("There was an error in creating the PascalSet:\r\n" + ae.Message);

            }
        }

        private void btnUnion_Click(object sender, EventArgs e)
        {
            try
            {
                int[] nums = GetIntArrayFromString(ints.Text);

                pSet = pSet.Union(nums);
                UpdateDisplay();
                ints.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem with unioning the integer list to the set:\r\n" + ex.Message);
            }
        }

        private void UpdateDisplay()
        {
            setContents.Text = "{ ";
            foreach (int i in pSet)
                setContents.Text += i + ", ";
            setContents.Text += " }";
        }

        private int[] GetIntArrayFromString(string str)
        {
            string[] addStrs = str.Split(new char[] { ',' });
            int[] add = new int[addStrs.Length];
            for (int i = 0; i < addStrs.Length; i++)
                add[i] = Convert.ToInt32(addStrs[i].Trim());

            return add;
        }

        private void btnIntersect_Click(object sender, EventArgs e)
        {
            try
            {
                int[] nums = GetIntArrayFromString(ints.Text);

                pSet = pSet.Intersection(nums);
                UpdateDisplay();
                ints.Text = String.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem with intersecting the integer list with the set:\r\n" + ex.Message);
            }
        }

        private void btnDifference_Click(object sender, EventArgs e)
        {
            try
            {
                int[] nums = GetIntArrayFromString(ints.Text);

                pSet = pSet.Difference(nums);
                UpdateDisplay();
                ints.Text = String.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem with set differencing the integer list with the set:\r\n" + ex.Message);
            }
        }

        private void btnComplement_Click(object sender, EventArgs e)
        {
            pSet = pSet.Complement();
            UpdateDisplay();
        }

        private void btnIsSubset_Click(object sender, EventArgs e)
        {
            try
            {
                int[] nums = GetIntArrayFromString(ints.Text);

                if (pSet.Subset(nums))
                    MessageBox.Show(this.setContents.Text + " is a subset of {" + ints.Text + "}");
                else
                    MessageBox.Show(this.setContents.Text + " is NOT a subset of {" + ints.Text + "}");

                ints.Text = String.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem with checking the subset for the integer list with the set:\r\n" + ex.Message);
            }
        }

        private void btnProperSubset_Click(object sender, EventArgs e)
        {
            try
            {
                int[] nums = GetIntArrayFromString(ints.Text);

                if (pSet.ProperSubset(nums))
                    MessageBox.Show(this.setContents.Text + " is a proper subset of {" + ints.Text + "}");
                else
                    MessageBox.Show(this.setContents.Text + " is NOT a proper subset of {" + ints.Text + "}");

                ints.Text = String.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem with checking the proper subset for the integer list with the set:\r\n" + ex.Message);
            }
        }

        private void btnCountCharacters_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Choose a text file to open.  Using a character set, the program will provide some stats about the file.");
            if (this.openFileDlg.ShowDialog() == DialogResult.OK)
            {
                // read in the file's contents
                StreamReader sr = File.OpenText(openFileDlg.FileName);
                string fileContents = sr.ReadToEnd().ToLower();
                sr.Close();

                PascalSet vowels = new PascalSet('a', 'z');
                vowels = vowels.Union('a', 'e', 'i', 'o', 'u');
                PascalSet consonants = vowels.Complement();

                int vCount = 0, cCount = 0, oCount = 0;
                for (int i = 0; i < fileContents.Length; i++)
                {
                    char c = fileContents[i];
                    if (vowels.ContainsElement(c))
                        vCount++;
                    else if (consonants.ContainsElement(c))
                        cCount++;
                    else
                        oCount++;
                }

                MessageBox.Show("In the file there were " + vCount.ToString() + " vowels, " + cCount.ToString() + " consonants, and " + oCount.ToString() + " non-alphabetic characters.");
            }
        }
    }
}