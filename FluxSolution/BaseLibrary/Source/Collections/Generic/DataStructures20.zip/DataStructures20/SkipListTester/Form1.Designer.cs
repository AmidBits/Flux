﻿namespace SkipListTester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.val = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnContains = new System.Windows.Forms.Button();
            this.skipListView = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnRunTests = new System.Windows.Forms.Button();
            this.ops = new System.Windows.Forms.NumericUpDown();
            this.rndSeed = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.saveLogFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ops)).BeginInit();
            this.SuspendLayout();
// 
// label1
// 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Value:";
// 
// val
// 
            this.val.Location = new System.Drawing.Point(47, 9);
            this.val.Name = "val";
            this.val.Size = new System.Drawing.Size(57, 20);
            this.val.TabIndex = 1;
// 
// btnAdd
// 
            this.btnAdd.Location = new System.Drawing.Point(120, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
// 
// btnRemove
// 
            this.btnRemove.Location = new System.Drawing.Point(213, 5);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
// 
// btnContains
// 
            this.btnContains.Location = new System.Drawing.Point(313, 5);
            this.btnContains.Name = "btnContains";
            this.btnContains.TabIndex = 4;
            this.btnContains.Text = "Contains?";
            this.btnContains.Click += new System.EventHandler(this.btnContains_Click);
// 
// skipListView
// 
            this.skipListView.AutoSize = false;
            this.skipListView.Location = new System.Drawing.Point(13, 47);
            this.skipListView.Multiline = true;
            this.skipListView.Name = "skipListView";
            this.skipListView.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.skipListView.Size = new System.Drawing.Size(568, 62);
            this.skipListView.TabIndex = 5;
            this.skipListView.WordWrap = false;
// 
// groupBox1
// 
            this.groupBox1.Controls.Add(this.btnRunTests);
            this.groupBox1.Controls.Add(this.ops);
            this.groupBox1.Controls.Add(this.rndSeed);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(47, 134);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(516, 88);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SkipList Stress Tester";
// 
// btnRunTests
// 
            this.btnRunTests.Location = new System.Drawing.Point(206, 58);
            this.btnRunTests.Name = "btnRunTests";
            this.btnRunTests.Size = new System.Drawing.Size(135, 23);
            this.btnRunTests.TabIndex = 4;
            this.btnRunTests.Text = "Commence Testing";
            this.btnRunTests.Click += new System.EventHandler(this.btnRunTests_Click);
// 
// ops
// 
            this.ops.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ops.Location = new System.Drawing.Point(133, 20);
            this.ops.Maximum = new decimal(new int[] {
            2000000,
            0,
            0,
            0});
            this.ops.Minimum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.ops.Name = "ops";
            this.ops.TabIndex = 3;
            this.ops.ThousandsSeparator = true;
            this.ops.Value = new decimal(new int[] {
            1024,
            0,
            0,
            0});
// 
// rndSeed
// 
            this.rndSeed.Location = new System.Drawing.Point(381, 20);
            this.rndSeed.Name = "rndSeed";
            this.rndSeed.TabIndex = 2;
// 
// label3
// 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(296, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 14);
            this.label3.TabIndex = 1;
            this.label3.Text = "Random seed:";
// 
// label2
// 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Number of Operations:";
// 
// saveLogFileDlg
// 
            this.saveLogFileDlg.DefaultExt = "log";
            this.saveLogFileDlg.Filter = "Log Files|*.log|All Files|*.*";
// 
// Form1
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(593, 246);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.skipListView);
            this.Controls.Add(this.btnContains);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.val);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "SkipList Tester";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ops)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox val;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnContains;
        private System.Windows.Forms.TextBox skipListView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox rndSeed;
        private System.Windows.Forms.NumericUpDown ops;
        private System.Windows.Forms.Button btnRunTests;
        private System.Windows.Forms.SaveFileDialog saveLogFileDlg;
    }
}

