﻿#region Using directives

using System;
using System.IO;
using SkmDataStructures2;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace SkipListTester
{
    partial class Form1 : Form
    {
        SkipList<string> list = new SkipList<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            list.Add(val.Text);
            ShowList();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (list.Remove(val.Text))
                ShowList();
            else
                MessageBox.Show("Item " + val.Text + " was not found in the SkipList.");
        }

        private void btnContains_Click(object sender, EventArgs e)
        {
            if (list.Contains(val.Text))
                MessageBox.Show("Item " + val.Text + " WAS found in the SkipList.");
            else
                MessageBox.Show("Item " + val.Text + " was NOT found in the SkipList.");
        }

        private void ShowList()
        {
            skipListView.Text = list.ToString();
        }

        private void btnRunTests_Click(object sender, EventArgs e)
        {
            // prompt the user to select a place to save the log file
            if (this.saveLogFileDlg.ShowDialog() == DialogResult.OK)
            {
                // the user has opted to save the file, run tests!
                Random rnd;
                SkipList<int> tempSL;
                long totalComps = 0;

                if (rndSeed.Text.Length > 0)
                {
                    rnd = new Random(Convert.ToInt32(rndSeed.Text));
                    tempSL = new SkipList<int>(Convert.ToInt32(rndSeed.Text));
                }
                else
                {
                    rnd = new Random();
                    tempSL = new SkipList<int>();
                }


                // start by running some inserts
                StreamWriter sw = File.CreateText(this.saveLogFileDlg.FileName);
                for (int i = 0; i < this.ops.Value / 2; i++)
                {
                    int adding = rnd.Next(Convert.ToInt32(ops.Value));
                    sw.Write("Adding " + adding.ToString());

                    tempSL.ResetComparisons();
                    tempSL.Add(adding);
                    totalComps += tempSL.Comparisons;
                    sw.WriteLine(" (" + tempSL.Comparisons + " comps, " + tempSL.Count.ToString() + " items, height " + tempSL.Height.ToString() + ")");
                }

                // now, do a mix of inserts/deletes/lookups
                for (int i = 0; i < this.ops.Value / 2; i++)
                {
                    int val = rnd.Next(Convert.ToInt32(ops.Value));

                    switch (rnd.Next(3))
                    {
                        case 0:	// insert
                            sw.Write("Adding " + val.ToString());

                            tempSL.ResetComparisons();
                            tempSL.Add(val);
                            sw.WriteLine(" (" + tempSL.Comparisons + " comps, " + tempSL.Count.ToString() + " items, height " + tempSL.Height.ToString() + ")");
                            totalComps += tempSL.Comparisons;
                            break;

                        case 1: // delete
                            sw.Write("Removing " + val.ToString());

                            tempSL.ResetComparisons();
                            tempSL.Remove(val);
                            sw.WriteLine(" (" + tempSL.Comparisons + " comps, " + tempSL.Count.ToString() + " items, height " + tempSL.Height.ToString() + ")");
                            totalComps += tempSL.Comparisons;
                            break;

                        case 2: // lookup
                            sw.Write("Contains " + val.ToString());

                            tempSL.ResetComparisons();
                            if (tempSL.Contains(val))
                                sw.Write(" FOUND ");
                            else
                                sw.Write(" NOT FOUND ");

                            sw.WriteLine(" (" + tempSL.Comparisons + " comps, " + tempSL.Count.ToString() + " items, height " + tempSL.Height.ToString() + ")");
                            totalComps += tempSL.Comparisons;
                            break;
                    }
                }

                double avgComps = Convert.ToDouble(totalComps) / Convert.ToDouble(ops.Value);

                sw.WriteLine("");
                sw.WriteLine("TOTAL NODES IN SKIPLIST: " + tempSL.Count.ToString());
                sw.WriteLine("HEIGHT OF SKIPLIST: " + tempSL.Height.ToString());
                sw.WriteLine("TOTAL # OF COMPARISONS: " + totalComps.ToString());
                sw.WriteLine("AVERAGE # OF COMPARISONS PER OPERATION: " + avgComps.ToString());

                sw.Close();
                tempSL = null;

                MessageBox.Show("Test Complete... " + totalComps.ToString() +
                                " total comparisons with an average of " + avgComps.ToString() +
                                " comparisons per operation...");
            }
        }


    }
}