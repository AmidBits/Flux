namespace Flux.Collections.Generic
{
  internal abstract class HeapComparer<T>
    : System.Collections.Generic.IComparer<T>, System.Collections.Generic.IEqualityComparer<T>
  {
    protected readonly System.Collections.Generic.IComparer<T> m_comparer;
    public System.Collections.Generic.IComparer<T> Comparer => m_comparer;

    protected readonly System.Collections.Generic.IEqualityComparer<T> m_equalityComparer;
    public System.Collections.Generic.IEqualityComparer<T> EqualityComparer => m_equalityComparer;

    internal HeapComparer(System.Collections.Generic.IComparer<T>? comparer, System.Collections.Generic.IEqualityComparer<T>? equalityComparer)
    {
      m_comparer = comparer ?? System.Collections.Generic.Comparer<T>.Default;
      m_equalityComparer = equalityComparer ?? System.Collections.Generic.EqualityComparer<T>.Default;
    }
    internal HeapComparer(System.Collections.Generic.IComparer<T>? comparer) : this(comparer, null) { }
    internal HeapComparer(System.Collections.Generic.IEqualityComparer<T>? equalityComparer) : this(null, equalityComparer) { }
    internal HeapComparer() : this(null, null) { }

    public abstract int Compare(T x, T y);

    public bool Equals(T x, T y) => m_equalityComparer.Equals(x, y);

    public int GetHashCode(T obj) => obj.GetHashCode();
  }

  internal class HeapComparerMax<T>
    : HeapComparer<T>
  {
    public static HeapComparerMax<T> Default = new HeapComparerMax<T>(System.Collections.Generic.Comparer<T>.Default);

    internal HeapComparerMax(System.Collections.Generic.IComparer<T>? comparer) : base(comparer) { }

    public override int Compare(T x, T y) => m_comparer.Compare(y, x);
  }

  internal class HeapComparerMin<T>
    : HeapComparer<T>
  {
    public static HeapComparerMin<T> Default = new HeapComparerMin<T>(System.Collections.Generic.Comparer<T>.Default);

    internal HeapComparerMin(System.Collections.Generic.IComparer<T>? comparer) : base(comparer) { }

    public override int Compare(T x, T y) => m_comparer.Compare(x, y);
  }
}
