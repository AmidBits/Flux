using System.Linq;

namespace Flux.Collections.Generic
{
  /// <summary>
  /// A pairing minMax heap implementation.
  /// </summary>
  public class PairingHeap<T>
    : System.Collections.Generic.IEnumerable<T>, System.ICloneable
  {
    private HeapComparer<T> m_comparer;

    private System.Collections.Generic.Dictionary<T, System.Collections.Generic.List<Node>> m_heapMapping;

    private Node m_root;

    private PairingHeap(HeapComparer<T> comparer)
    {
      m_comparer = comparer;

      m_heapMapping = new System.Collections.Generic.Dictionary<T, System.Collections.Generic.List<Node>>(comparer);
    }
    private PairingHeap(HeapComparer<T> comparer, System.Collections.Generic.IEnumerable<T> collection) : this(comparer) => InsertRange(collection);

    public int Count { get; private set; }

    public object Clone() => Clone(false);
    public PairingHeap<T> Clone(bool reversePriority)
    {
      switch (m_comparer)
      {
        case HeapComparerMax<T> max:
          return reversePriority ? CreateMin(m_heapMapping.SelectMany(x => x.Value).Select(x => x.Value)) : CreateMax(m_heapMapping.SelectMany(x => x.Value).Select(x => x.Value));
        case HeapComparerMin<T> min:
          return reversePriority ? CreateMax(m_heapMapping.SelectMany(x => x.Value).Select(x => x.Value)) : CreateMin(m_heapMapping.SelectMany(x => x.Value).Select(x => x.Value));
        default:
          throw new System.NotSupportedException();
      }
    }

    /// <summary>
    /// Insert a new Node.
    /// Time complexity: O(1).
    /// </summary>
    public void Insert(T newValue)
    {
      var newNode = new Node(newValue);
      m_root = Meld(m_root, newNode);
      AddMapping(newValue, newNode);
      Count++;
    }
    public void InsertRange(System.Collections.Generic.IEnumerable<T> collection)
    {
      foreach (var item in collection)
      {
        Insert(item);
      }
    }

    /// <summary>
    /// Time complexity: O(log(n)).
    /// </summary>
    public T Extract()
    {
      var minMax = m_root;
      RemoveMapping(minMax.Value, minMax);
      Meld(m_root.ChildrenHead);
      Count--;
      return minMax.Value;
    }
    public System.Collections.Generic.IEnumerable<T> ExtractRange()
    {
      while (Count > 0)
      {
        yield return Extract();
      }
    }

    public virtual System.Collections.Generic.IEnumerator<T> GetEnumerator() => Clone(false).ExtractRange().GetEnumerator();

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();

    /// <summary>
    /// Merge another heap with this heap.
    /// Time complexity: O(1).
    /// </summary>
    public void Merge(PairingHeap<T> PairingHeap)
    {
      m_root = Meld(m_root, PairingHeap.m_root);
      Count = Count + PairingHeap.Count;
    }

    /// <summary>
    /// Time complexity: O(1).
    /// </summary>
    public T Peek()
    {
      if (m_root == null)
        throw new System.Exception("Empty heap");

      return m_root.Value;
    }

    /// <summary>
    /// Time complexity: O(log(n)).
    /// </summary>
    public void UpdateKey(T currentValue, T newValue)
    {
      var node = m_heapMapping[currentValue]?.Where(x => x.Value.Equals(currentValue)).FirstOrDefault();

      if (node == null)
      {
        throw new System.Exception("Current value is not present in this heap.");
      }

      if (m_comparer.Compare(newValue, node.Value) > 0)
      {
        throw new System.Exception($"New value is not {m_comparer.GetType().Name} than old value.");
      }

      UpdateNodeValue(currentValue, newValue, node);

      if (node == m_root)
      {
        return;
      }

      DeleteChild(node);

      m_root = Meld(m_root, node);
    }

    /// <summary>
    /// Time complexity: O(log(n))
    /// </summary>
    private void Meld(Node headNode)
    {
      if (headNode == null)
        return;

      var passOneResult = new System.Collections.Generic.List<Node>();

      var current = headNode;

      if (current.Next == null)
      {
        headNode.Next = null;
        headNode.Previous = null;
        passOneResult.Add(headNode);
      }
      else
      {
        while (true)
        {
          if (current == null)
          {
            break;
          }

          if (current.Next != null)
          {
            var next = current.Next;
            var nextNext = next.Next;
            passOneResult.Add(Meld(current, next));
            current = nextNext;
          }
          else
          {
            var lastInserted = passOneResult[passOneResult.Count - 1];
            passOneResult[passOneResult.Count - 1] = Meld(lastInserted, current);
            break;

          }
        }

      }

      var passTwoResult = passOneResult[passOneResult.Count - 1];

      if (passOneResult.Count == 1)
      {
        m_root = passTwoResult;
        return;
      }


      for (var i = passOneResult.Count - 2; i >= 0; i--)
      {
        current = passOneResult[i];
        passTwoResult = Meld(passTwoResult, current);
      }

      m_root = passTwoResult;
    }

    /// <summary>
    /// makes the smaller node parent of other and returns the Parent
    /// </summary>
    private Node Meld(Node node1, Node node2)
    {
      if (node2 != null)
      {
        node2.Previous = null;
        node2.Next = null;
      }

      if (node1 == null)
      {
        return node2;
      }

      node1.Previous = null;
      node1.Next = null;

      if (node2 != null && m_comparer.Compare(node1.Value, node2.Value) <= 0)
      {

        AddChild(ref node1, node2);
        return node1;
      }

      AddChild(ref node2, node1);
      return node2;
    }

    private void AddChild(ref Node parent, Node child)
    {
      if (parent.ChildrenHead == null)
      {
        parent.ChildrenHead = child;
        child.Previous = parent;
        return;
      }

      var head = parent.ChildrenHead;

      child.Previous = head;
      child.Next = head.Next;

      if (head.Next != null)
      {
        head.Next.Previous = child;
      }

      head.Next = child;

    }

    private void DeleteChild(Node node)
    {
      //if this node is the child head pointer of parent
      if (node.IsHeadChild)
      {
        var parent = node.Previous;

        //use close sibling as new parent child pointer
        if (node.Next != null)
        {
          node.Next.Previous = parent;
        }

        parent.ChildrenHead = node.Next;
      }
      else
      {
        //just do regular deletion from linked list
        node.Previous.Next = node.Next;

        if (node.Next != null)
        {
          node.Next.Previous = node.Previous;
        }
      }
    }

    private void AddMapping(T newValue, Node newNode)
    {
      if (m_heapMapping.ContainsKey(newValue))
      {
        m_heapMapping[newValue].Add(newNode);
      }
      else
      {
        m_heapMapping[newValue] = new System.Collections.Generic.List<Node>(new[] { newNode });
      }
    }

    private void UpdateNodeValue(T currentValue, T newValue, Node node)
    {
      RemoveMapping(currentValue, node);

      node.Value = newValue;

      AddMapping(newValue, node);
    }

    private void RemoveMapping(T currentValue, Node node)
    {
      m_heapMapping[currentValue].Remove(node);

      if (m_heapMapping[currentValue].Count == 0) m_heapMapping.Remove(currentValue);
    }

    public static PairingHeap<T> CreateMax() => new PairingHeap<T>(new HeapComparerMax<T>(null));
    public static PairingHeap<T> CreateMax(System.Collections.Generic.IEnumerable<T> collection) => new PairingHeap<T>(new HeapComparerMax<T>(null), collection);

    public static PairingHeap<T> CreateMin() => new PairingHeap<T>(new HeapComparerMin<T>(null));
    public static PairingHeap<T> CreateMin(System.Collections.Generic.IEnumerable<T> collection) => new PairingHeap<T>(new HeapComparerMin<T>(null), collection);

    internal class Node
    {
      internal T Value { get; set; }

      internal Node ChildrenHead { get; set; }
      internal bool IsHeadChild => Previous != null && Previous.ChildrenHead == this;

      internal Node(T value) => Value = value;

      internal Node Previous;
      internal Node Next;
    }
  }
}
