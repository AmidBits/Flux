using System.Linq;

namespace Flux.Collections.Generic
{
  public sealed class PriorityQueue<TPriority, TValue>
    : System.ICloneable, System.Collections.Generic.IReadOnlyCollection<TValue>
  {
    private System.Collections.Generic.SortedDictionary<TPriority, System.Collections.Generic.Queue<TValue>> m_data;

    public int Count { get; private set; }

    private PriorityQueue(HeapComparer<TPriority> comparer) => m_data = new System.Collections.Generic.SortedDictionary<TPriority, System.Collections.Generic.Queue<TValue>>(comparer);
    private PriorityQueue(HeapComparer<TPriority> comparer, System.Collections.Generic.IEnumerable<(TPriority, TValue)> collection) : this(comparer) => EnqueueRange(collection);

    public void Clear() => m_data.Clear();

    public object Clone() => Clone(false);
    public PriorityQueue<TPriority, TValue> Clone(bool reversePriority)
    {
      switch (m_data.Comparer)
      {
        case HeapComparerMax<TPriority> max:
          return reversePriority ? CreateMin(Dump()) : CreateMax(Dump());
        case HeapComparerMin<TPriority> min:
          return reversePriority ? CreateMax(Dump()) : CreateMin(Dump());
        default:
          throw new System.NotSupportedException();
      }
    }

    public bool ContainsPriority(TPriority priority) => Count > 0 ? m_data.ContainsKey(priority) : false;
    public bool ContainsValue(TValue value) => Count > 0 ? m_data.Any(kvp => kvp.Value.Contains(value)) : false;

    public System.Collections.Generic.IEnumerable<(TPriority, TValue)> Dump()
    {
      foreach (var kvp in m_data)
      {
        foreach (var value in kvp.Value)
        {
          yield return (kvp.Key, value);
        }
      }
    }

    public (TPriority, TValue) Dequeue()
    {
      if (Count > 0)
      {
        var priority = m_data.First();

        var priorityAndValue = (priority.Key, priority.Value.Dequeue());

        Count--;

        if (priority.Value.Count == 0) m_data.Remove(priority.Key);

        return priorityAndValue;
      }
      else throw new System.InvalidOperationException($"The {this.GetType().Name} is empty.");
    }
    public System.Collections.Generic.IEnumerable<(TPriority, TValue)> DequeueRange()
    {
      while (Count > 0)
      {
        yield return Dequeue();
      }
    }

    public void Enqueue(TPriority priority, TValue value)
    {
      if (!ContainsPriority(priority)) m_data.Add(priority, new System.Collections.Generic.Queue<TValue>());

      m_data[priority].Enqueue(value);

      Count++;
    }
    public void EnqueueRange(TPriority priority, System.Collections.Generic.IEnumerable<TValue> values)
    {
      foreach (var value in values)
      {
        Enqueue(priority, value);
      }
    }
    public void EnqueueRange(System.Collections.Generic.IEnumerable<(TPriority priority, TValue value)> collection)
    {
      foreach (var pv in collection)
      {
        Enqueue(pv.priority, pv.value);
      }
    }

    public System.Collections.Generic.IEnumerator<TValue> GetEnumerator() => Values().GetEnumerator();
    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();

    public TValue Peek() => Count > 0 ? m_data.First().Value.Peek() : throw new System.InvalidOperationException($"The {this.GetType().Name} is empty.");

    public System.Collections.Generic.IEnumerable<TPriority> Priorities => m_data.Keys;

    public System.Collections.Generic.IEnumerable<TValue> Values()
    {
      foreach (var kvp in m_data)
      {
        foreach (var item in kvp.Value)
        {
          yield return item;
        }
      }
    }
    public System.Collections.Generic.IEnumerable<TValue> Values(TPriority priority)
    {
      foreach (var value in m_data[priority])
      {
        yield return value;
      }
    }

    public static PriorityQueue<TPriority, TValue> CreateMax() => new PriorityQueue<TPriority, TValue>(new HeapComparerMax<TPriority>(null));
    public static PriorityQueue<TPriority, TValue> CreateMax(System.Collections.Generic.IEnumerable<(TPriority, TValue)> collection) => new PriorityQueue<TPriority, TValue>(new HeapComparerMax<TPriority>(null), collection);

    public static PriorityQueue<TPriority, TValue> CreateMin() => new PriorityQueue<TPriority, TValue>(new HeapComparerMin<TPriority>(null));
    public static PriorityQueue<TPriority, TValue> CreateMin(System.Collections.Generic.IEnumerable<(TPriority, TValue)> collection) => new PriorityQueue<TPriority, TValue>(new HeapComparerMin<TPriority>(null), collection);
  }
}
